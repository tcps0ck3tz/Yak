#pragma once

#define HTTP_SERVER "194.34.134.13"
#define HTTP_PORT 80

#define TFTP_SERVER "194.34.134.13"
